<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="gameboy_forest_tileset_rohangb.itch.io" tilewidth="8" tileheight="8" tilecount="480" columns="24">
 <image source="gameboy_forest_tileset_rohangb.itch.io.png" width="192" height="160"/>
</tileset>
