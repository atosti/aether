<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="RPG_exterior" tilewidth="8" tileheight="8" tilecount="408" columns="24">
 <image source="RPG_exterior.png" width="192" height="136"/>
</tileset>
