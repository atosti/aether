<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="RPG_interior" tilewidth="8" tileheight="8" tilecount="286" columns="22">
 <image source="RPG_interior.png" width="176" height="104"/>
</tileset>
