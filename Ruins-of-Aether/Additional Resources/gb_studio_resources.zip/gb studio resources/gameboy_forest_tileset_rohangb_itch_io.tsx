<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="gameboy_forest_tileset_rohangb_itch_io" tilewidth="16" tileheight="16" tilecount="120" columns="12">
 <image source="gameboy_forest_tileset_rohangb.itch.io.png" width="192" height="160"/>
</tileset>
