# Condensed font pack for GB Studio 3
https://edo999.itch.io/condensed-fonts

## License
This work is licensed under a [Creative Commons Attribution-NoDerivatives 4.0 International License](http://creativecommons.org/licenses/by-nd/4.0/).

## Credits
Credits are required. Here is the suggested credit line:

> Condensed font pack by edo999 (edo999.itch.io).
